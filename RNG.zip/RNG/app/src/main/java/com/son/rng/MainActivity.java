package com.son.rng;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private TextView ball1;
    private TextView ball2;
    private TextView ball3;
    private TextView ball4;
    private TextView ball5;
    private TextView gball;
    private String allBalls;
    private CheckBox cbUnique;
    private Object OnSeekBarChangeListener;
    private int rangeW;
    private int rangeG;
    private String message;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final ArrayList<Integer> ticket = new ArrayList <Integer>();

        Button button = (Button) findViewById(R.id.generatebutton);
        Button copyButton = (Button) findViewById(R.id.copybutton);
        Button copyAllButton = (Button) findViewById(R.id.copyAllButton);
        textView = (TextView) findViewById(R.id.textView2);
        textView.setText("");
        textView.setMovementMethod(new ScrollingMovementMethod());
        ball1 = (TextView) findViewById(R.id.wball1Text);
        ball1.setText("");
        ball2 = (TextView) findViewById(R.id.wball2Text);
        ball2.setText("");
        ball3 = (TextView) findViewById(R.id.wball3Text);
        ball3.setText("");
        ball4 = (TextView) findViewById(R.id.wball4Text);
        ball4.setText("");
        ball5 = (TextView) findViewById(R.id.wball5Text);
        ball5.setText("");
        gball = (TextView) findViewById(R.id.gballText);
        gball.setText("");
        cbUnique = findViewById(R.id.checkBoxUnique);
        final SeekBar seekBar = findViewById(R.id.range);
        final TextView seekBarText = findViewById(R.id.seekBarTextView);
        final SeekBar seekBar2 = findViewById(R.id.range2);
        final TextView seekBarText2 = findViewById(R.id.seekBarTextView2);

        SeekBar sk = (SeekBar) findViewById(R.id.range);
        sk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                seekBarText.setText(String.valueOf(i));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        SeekBar sk2 = (SeekBar) findViewById(R.id.range2);
        sk2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override
            public void onProgressChanged(SeekBar seekBar2, int i, boolean b) {
                seekBarText2.setText(String.valueOf(i));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar2) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar2) {

            }
        });

        View.OnClickListener ourGenerateOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //String result = userInput.getText().toString();
                //Random r = new Random();
                //int i1 = r.nextInt(69);
                //textView.append(String.valueOf(i1) + " ");

                //uses seekbar values for ranges
                rangeW = seekBar.getProgress();
                rangeG = seekBar2.getProgress();

                //Start of draw function
                ArrayList ticket = (ArrayList)generateRandom.draw(cbUnique.isChecked(), rangeW).clone();

                String numbers;
                numbers = ticket.toString();
                Random r = new Random();
                int pb = r.nextInt(rangeG) + 1;

                textView.append(numbers + " Lucky Ball: [" + pb + "]" + "\n");

                final int scrollAmount = textView.getLayout().getLineTop(textView.getLineCount()) - textView.getHeight();
                if (scrollAmount > 0)
                    textView.scrollTo(0,scrollAmount);
                else
                    textView.scrollTo(0,0);


                    ball1.setText((Integer) ticket.get(0) + ""); //Gets ArrayList at the indicated index and sets as Integer. It needs the + "" for it to work correctly.
                    ball2.setText((Integer) ticket.get(1) + "");
                    ball3.setText((Integer) ticket.get(2) + "");
                    ball4.setText((Integer) ticket.get(3) + "");
                    ball5.setText((Integer) ticket.get(4) + "");
                    gball.setText(pb + "");
                    allBalls = ball1.getText()+","+ball2.getText()+","+ball3.getText()+","+ball4.getText()+","+ball5.getText()+","+gball.getText();

            }

        };

        button.setOnClickListener(ourGenerateOnClickListener);

        View.OnClickListener ourCopyOnClickListener = new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Ticket",allBalls);
                clipboard.setPrimaryClip(clip);
                toastMessage("Copied to clipboard.");
            }
        };

        copyButton.setOnClickListener(ourCopyOnClickListener);

        View.OnClickListener ourCopyAllOnClickListener = new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("All Tickets",textView.getText());
                clipboard.setPrimaryClip(clip);
                toastMessage("Copied to clipboard.");
            }
        };

        copyAllButton.setOnClickListener(ourCopyAllOnClickListener);

    }

    public void toastMessage(String message){
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }
}
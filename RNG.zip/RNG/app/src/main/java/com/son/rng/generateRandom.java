package com.son.rng;

import android.content.Context;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public abstract class generateRandom extends Context {
    
    public static void main(String args[]) {
        
        // create instance of Random class
        //Random rand = new Random();

        // Generate random integers in range 1 to 70
        //int rand_int = rand.nextInt(70) + 1;

        // Print random integers
        //System.out.println("Random Integer: " + rand_int);

        // Generate Random doubles
        /*double rand_dub1 = rand.nextDouble();
        double rand_dub2 = rand.nextDouble();

        // Print random doubles
        System.out.println("Random Doubles: "+rand_dub1);
        System.out.println("Random Doubles: "+rand_dub2);*/

        //draw();
    }

    public static ArrayList<Integer> draw(boolean cbUnique, int range) {
        ArrayList<Integer> ticket = new ArrayList<Integer>();
        Random r = new Random();

        
        
        if (cbUnique == true) {
            if(range>=5) {
                while (ticket.size() < 5) {
                    int b = r.nextInt(range) + 1;
                    if (ticket.contains(b)) {
                        continue;
                    }
                    ticket.add(b);
                }
            }
            else {
                System.out.println("Error! Set range to be greater than 4 or uncheck 'Unique values'");
                ticket.add(0);
                ticket.add(0);
                ticket.add(0);
                ticket.add(0);
                ticket.add(0);

            }
        }
        else {
            while (ticket.size() < 5) {
                int b = r.nextInt(range) + 1;
                ticket.add(b);
            }
        }
        Collections.sort(ticket);
        return ticket;
    }
}